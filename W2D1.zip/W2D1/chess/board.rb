#REFACTOR: public, protected and private

require_relative 'piece'
require_relative 'display'
require 'byebug'

class Board
  attr_accessor :grid, :pos
  attr_reader :display

  def initialize(size = 8)
    @grid = Array.new(size) { Array.new(size) }
    @display = Display.new(grid)
  end

  def populate
    grid.each_with_index do |row, idx|
      row.each_with_index { |_, idx2| self[[idx, idx2]] = Piece.new([idx, idx2], self) }
    end
  end

  def [](pos)
    x,y = pos
    grid[x][y]
  end

  def []=(pos, value)
    x,y = pos
    grid[x][y] = value
  end

  def move_piece(start_pos, end_pos)
    #duck type for computer_player and human_player
    # begin
    #   # start_pos = player.get_move #gets.chomp helper method called on player
    #   raise ArgumentError.new("No piece at that position.") if self[start_pos].nil?
    # rescue
    #   puts "Try again."
    #   retry
    #   # end_pos = player.get_move #gets.chomp
    # # rescue message if the piece cannot move to end_pos
    #   raise InvalidMove.new("Cannot move there.") unless valid_move? #helper method
    # rescue
    #   puts "Try again."
    #   retry
    # end
    self[end_pos] = self[start_pos]
    self[start_pos].pos = end_pos
    self[start_pos] = nil #NilPiece later
  end

  def in_bounds?(pos)
    x,y = pos
    (0..7).to_a.include?(x) &&
    (0..7).to_a.include?(y)
  end
end
