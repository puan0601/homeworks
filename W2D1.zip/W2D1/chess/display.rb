require_relative 'board'
require_relative 'cursor'
require_relative 'piece'
require 'colorize'
require 'byebug'

class Display
  attr_reader :board, :grid
  def initialize(board)
    @cursor = Cursor.new([0, 0], board)
    @board = board
  end

  def render
    (0..7).each {|i| print "   #{i}"}
    print "\n"
    board.grid.each_with_index do |row, index|
      print "#{index}  "
      row.each do |el|
        if @cursor.cursor_pos == el.pos #@ because calling instance of cursor
          print el.to_s.colorize(color: :white, background: :blue).blink
        else
          print el.to_s
        end
        print "   "
      end

      puts ""
    end
  end

  def play
    while true
      render
      @cursor.get_input
    end
  end

end
