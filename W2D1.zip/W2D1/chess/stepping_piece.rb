require_relative 'piece'

module SteppingPiece
  def moves(start_pos, end_pos)
    #add moves_diff to start_pos, put them in an Array
    #test these coordinates to make sure they are valid:
    #1. must be in bounds
    #2. can't go on top of another piece of the same color
    #3. can't go further than a piece of opposite color blocking it;
    # would take over that piece's position instead.
  end
end

class Knight < Piece
  include SteppingPiece

  def symbol
    black_knight = "\u265E"
    white_knight = "\u2658"
  end

  def move_dirs
    dirs = [[-1, -2], [-1, 2], [1, -2], [1, 2],
    [-2, -1], [-2, 1], [2, -1], [2, 1]]
  end
end


class King < Piece
  include SteppingPiece
  
  def symbol
    black_king = "\u265A"
    white_king = "\u2654"
  end

  def move_dirs
    diff = [[-1, 0], [-1, 1], [0, 1], [1, 1],
    [1, 0], [-1, 1], [0, -1], [-1, -1]]
  end
end
