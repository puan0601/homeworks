require_relative 'board'

class Piece
  attr_accessor :pos
  attr_reader :board

  def initialize(pos, board)
    @pos = pos
    @board = board
  end

  def to_s
    "*"
  end

  def moves(start_pos, end_pos)
    #should return an [array] of places a Piece can move to.
  end

  # def [](pos)
  #   x,y = pos
  #   self[x][y]
  # end
  #
  # def []=(pos, value)
  #   x,y = pos
  #   self[x][y] = value
  # end
  # def populate
  #   NullPiece.populate
  # end
end
