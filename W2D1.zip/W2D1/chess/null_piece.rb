require_relative 'piece'
require_relative 'board'

class NullPiece < Piece
  def initialize(pos)
    super
  end

  def populate
    [2,5].each do |x|
      [0..7].each do |y|
        @grid[x, y] = NullPiece.new(x,y)
      end
    end
    grid
  end
end
