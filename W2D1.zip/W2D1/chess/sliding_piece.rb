require_relative 'piece'

module SlidingPiece
  def moves(start_pos, end_pos)
    #add moves_diff to start_pos, put them in an Array (but you'll need to keep adding
    #in each direction til out of bounds)
    #test these coordinates to make sure they are valid:
    #1. must be in bounds
    #2. can't go on top of another piece of the same color
    #3. can't go further than a piece of opposite color blocking it;
    # would take over that piece's position instead.

    x_diff = end_pos[0] - start_pos[0]
    y_diff = end_pos[1] - start_pos[1]
    move_dirs
  end
end

class Bishop < Piece
  include SlidingPiece

  def symbol
    black_bishop = "\u265D"
    white_bishop = "\u2657"
  end

  def move_dirs
    dirs = [[-1, 1], [1, 1], [-1, 1], [-1, -1]]
  end
end

class Rook < Piece
  include SlidingPiece
  
  def symbol
    black_rook = "\u265C"
    white_rook = "\u2656"
  end

  def move_dirs
    diff = [[-1, 0], [0, 1], [1, 0], [0, -1]]
  end
end

class Queen < Piece
  include SlidingPiece

  def symbol
    black_queen = "\u265B"
    white_queen = "\u2655"
  end

  def move_dirs
    dirs = [[-1, 0], [-1, 1], [0, 1], [1, 1],
    [1, 0], [-1, 1], [0, -1], [-1, -1]]
  end
end
