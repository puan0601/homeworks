class Employee
  attr_reader :bonus, :salary
  attr_accessor :employees, :name

  def initialize(name, title, salary, boss)
    @name = name
    @title = title
    @salary = salary
    @boss = boss
  end

  def bonus(multiplier)
    @bonus = salary * multiplier
  end

  def boss
    @boss
  end
end

class Manager < Employee
  attr_accessor :emp_list, :boss, :employees, :name


  def initialize(name, title, salary, boss)
    super
    @employees = employees
  end

  def bonus(multiplier)
    total_bonus = 0
    subordinates.each do |employee|
      total_bonus += employee.salary
    end

    total_bonus * multiplier
  end

  def subordinates
    subs = []

    employees.each do |employee|
      subs << employee
      if employee.is_a? Manager
        subs += employee.subordinates
      end
    end

    subs
  end

end

ned = Manager.new("Ned", "Founder", 1000000, nil)
darren = Manager.new("Darren", "TA Manager", 78000, ned)
shawna = Employee.new("Shawna", "TA", 12000, darren)
david = Employee.new("David", "TA", 10000, darren)
ned.employees = [darren]
darren.employees = [shawna, david]
ned.subordinates
p ned.bonus(5)
p darren.bonus(4)
p david.bonus(3)
