class HumanPlayer
  def initialize(name)
    @name = name
  end

  def prompt
    puts "Input your guess ie 1,2"
    gets.chomp.split(",").map { |el| Integer(el) }
  end
end





class ComputerPlayer
  attr_reader :known_cards, :matched_cards

  def initialize(name)
    @name = name
    @known_cards = {}
    @matched_cards = []
  end

  def receive_revealed_card(pos, val)
    @known_cards[pos] = val
  end

  def receive_match(pos1, pos2)
    @matched_cards += [pos1, pos2]
  end



  def prompt
  #   value_count = Hash.new(0)
  #   known_cards.each { |pos, card_value| value_count[card_value] += 1 }
  #
  #   value_count.each do |card_value, count|
  #     if count == 2
  #       pos_hash = known_cards.select { |pos, val| card_value == val }
  #       pos1, pos2 = pos_hash.keys
  #
  #     else
  #       #here
  #     end
  #   end
  #
  # end
  #
  # def

end
