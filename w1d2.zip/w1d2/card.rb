class Card
  attr_reader :face_value, :face_status

  def initialize(face_value)
    @face_value = face_value
    @face_status = false
  end

  def display
    return face_value if face_status
  end

  def hide
    @face_status = false if face_status
  end

  def reveal
    @face_status = true unless face_status
  end

  def to_s
    if face_status
      puts "The card value is #{face_value}."
    else
      puts "The card is face down."
    end

  end

  def ==(other_card)
    @face_value == other_card.face_value
  end

end
