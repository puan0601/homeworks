require 'byebug'
require_relative 'board'
require_relative 'card'
require_relative 'player'

class Game
  attr_accessor :board, :previous_guess, :player

  def initialize(board, player = HumanPlayer.new("Anton"))
    @board = board
    @player = player
    @previous_guess = 0
  end

  def play
    board.populate
    # debugger
    until over?
      sleep(2)
      #system 'clear'
      play_turn
    end

    p "You win!!!!!!!!!!!!!!!!!!!!!"
  end

  # def prompt
  #   puts "Input your guess ie 1,2"
  #   gets.chomp.split(",").map { |el| Integer(el) }
  # end
  def play_turn
    board.render
    @previous_guess = make_guess #returns card & flips a card
    board.render
    current_guess = make_guess
    board.render
    if previous_guess.face_value == current_guess.face_value
      puts "You found a pair"
    else
      puts "Those do not match"
      previous_guess.hide
      current_guess.hide
    end
  end

  def valid_move?(pos)
    return false if board[pos].nil? || board[pos].face_status
    true
  end

  def make_guess
    pos = player.prompt
    until valid_move?(pos)
      pos = player.prompt
    end
    board.reveal(pos)
    board[pos]
  end

  def over?
    board.won?
  end
end

if __FILE__ == $PROGRAM_NAME
  anton = Board.new
  Game.new(anton).play

end
