require_relative 'card.rb'

class Board
  attr_accessor :grid

  def initialize(grid = Array.new(4) { Array.new(4) })
    @grid = grid
  end

  def populate
    pop_arr = (1..8).to_a.shuffle
    (0..1).each do |row|
      (0..3).each do |col|
        @grid[row][col] = Card.new(pop_arr.pop)
      end
    end

    pop_arr = (1..8).to_a.shuffle
    (2..3).each do |row|
      (0..3).each do |col|
        @grid[row][col] = Card.new(pop_arr.pop)
      end
    end
  end

  def render
    grid.each do |row|
      row.each do |card|
        if card.face_status
          print "#{card.face_value} "
        else
          print "* "
        end
      end
      puts " "
    end
  end

  def won?
    grid.flatten.none? { |card| card.face_status == false }
  end

  def reveal(guessed_pos)
    unless self[guessed_pos].face_status
      self[guessed_pos].reveal
      self[guessed_pos] #return a card object
      #self[guessed_pos].face_value
    end
  end

  def [](pos)
    row, col = pos
    grid[row][col]
  end

  def []=(pos, value)
    row, col = pos
    @grid[row][col] = value
  end

end
