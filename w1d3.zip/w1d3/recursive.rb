# warmup+
require "byebug"

def range_rec(start, end_val)
  return [] if end_val < start
  return [end_val] if end_val == start
  range_rec(start, end_val - 1) + [end_val]
end

def range_iter(start, end_val)
  arr = []
  start.upto(end_val) { |i| arr << i }
  arr
end

def exp_1(b, n)
  return 1 if n == 0
  b * exp_1(b, n - 1)
end

def exp_2(b, n)
  return 1 if n == 0
  if n.even?
    exp_2(b, n / 2) ** 2
  else b * exp_2(b, (n - 1) / 2) ** 2
  end
end


def deep_dup(arr)
return arr if arr.size <= 1
  if arr[0].is_a?(Array)
    arr[0] + deep_dup(arr[1..-1])
  else [arr[0]] + deep_dup(arr[1..-1])
  end
end

def fib_r(n)
  return 1 if n == 1
  n * fib_r(n - 1)
end

def fib_i(n)
  (1..n).to_a.inject(1) { |sum, ele| sum *= ele }
end

def permut(arr)
  return [arr] if arr.size <= 1
  first_el = arr.shift

  perm = permut(arr)

  return_arr = []

  perm.each do |ele|
    (0..ele.length).each do |index|
      return_arr << ele[0...index] + [first_el] + ele[index..-1]
    end
  end
  return_arr
end

def bsearch(arr, target)
  return nil if arr.length == 1 && arr[0] != target
  # arr.sort!
  pos = arr.length / 2
  if arr[pos] == target
    return pos
  elsif arr[pos] > target
    bsearch(arr[0..pos], target)
  else
    sub_ans = bsearch(arr[(pos + 1)..-1],target)
    (sub_ans.nil?) ? nil : (pos + 1) + sub_ans
  end
end


def merge_sort(arr)
  half = arr.length / 2
  left_half = arr.take(half)
  right_half = arr.drop(half)
  return arr if arr.length == 1
  if arr.length > 1
    merge(merge_sort(left_half), merge_sort(right_half))
  end
end

def merge(arr1, arr2)
  final_arr = []
  until (arr1.empty? && arr2.empty?)
    if arr1.empty?
      final_arr << arr2.shift
    elsif arr2.empty?
      final_arr << arr1.shift
    else
      case arr1 <=> arr2
      when -1, 0 then final_arr << arr1.shift
      when 1 then final_arr << arr2.shift
      end
    end
  end
  final_arr
end

def subsets(arr)
  return [[]] if arr.empty?
  last = arr.last
  rest = arr[0..-2]
  temp = subsets(rest)
  temp + temp.map { |ele| ele += [last] }
end

def make_change(amount, coins = [25, 10, 5, 1])
  return [] if amount == 0
  result = []
  until amount < coins.first
    amount -= coins.first
    result << coins.first
  end
  result + make_change(amount, coins[1..-1])

end
