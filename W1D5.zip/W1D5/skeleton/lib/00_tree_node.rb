class PolyTreeNode
  attr_reader :parent
  attr_accessor :children, :value

  def initialize(value = nil)
    @value = value
    @parent = nil
    @children = []
  end

  def parent=(parent)
    if @parent
      @parent.children = @parent.children.reject do |child|
        child == self
      end
    end

    if parent.nil?
      @parent = nil
      return self
    end

    @parent = parent


    unless parent.children.include?(self)
      parent.children << self
    end
  end

  def add_child(child_node)
    child_node.parent = self
  end

  def remove_child(child_node)
    if child_node.parent == self
      child_node.parent = nil
    else
      raise "Hi you, the node is NOT a child"
    end
  end

  def dfs(target_value)
    return self if target_value == value

    children.each do |child|
      node = child.dfs(target_value)
      return node if node
    end
    nil
  end

  def bfs(target_value)
    queue = [self]
    until queue.empty?
      current_node = queue.shift
      return current_node if current_node.value == target_value

      current_node.children.each do |child|
        queue << child
      end
    end
    nil
  end
end
