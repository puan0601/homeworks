require_relative '00_tree_node'
require 'byebug'

class KnightPathFinder
attr_accessor :board, :visited_positions, :starting_pos

  def initialize(starting_pos = [0, 0])
    @board = Array.new(8) {Array.new(8) {PolyTreeNode.new} }
    board.each_with_index do |element, index1|
      element.each_with_index do |element, index2|
        board[index1][index2].value = [index1, index2]
      end
    end
    @starting_pos = starting_pos
    # @move_tree = build_move_tree(starting_pos)
    @visited_positions = [starting_pos]
  end

  def new_move_positions(pos)
    final_array = []
    x, y = pos
    eight_moves = [[(x - 1), (y + 2)], [(x - 2), (y + 1)],
    [(x - 2), (y - 1)], [(x - 1), (y - 2)], [(x + 1), (y + 2)],
    [(x + 2), (y + 1)], [(x + 2), (y - 1)], [(x + 1), (y - 2)]]

    eight_moves.each do |coordinate|
      final_array << coordinate if valid_move?(coordinate)
    end
    visited_positions << final_array
    final_array
  end

  def [](pos)
    x, y = pos
    board[x][y]
  end

  def build_move_tree(target)
    x, y = starting_pos
    queue = [@board[x][y]]
    until visited_positions.length >= 64
      current_node = queue.shift
      next_positions = new_move_positions(current_node.value)
      next_positions.each do |coordinate|
        x, y = coordinate
        p coordinate
        # current_node.add_child(@board[x][y])
        queue << @board[x][y]
        visited_positions << coordinate
      end
    end
  end

  def valid_move?(pos)
    x, y = pos
    return false if ((x < 0 || x > 8) || (y < 0 || y > 8) || visited_positions.include?(pos)) #add in previous spots
    true
  end
end

test = KnightPathFinder.new
test.build_move_tree([3,3])
p test.board[0][0]
